import tkinter as tk
from tkinter import messagebox

def calculate(operation):
    try:
        # Get the input numbers
        num1 = float(entry_num1.get())
        num2 = float(entry_num2.get())
        
        # Perform the selected operation
        if operation == "add":
            result = num1 + num2
        elif operation == "subtract":
            result = num1 - num2
        elif operation == "multiply":
            result = num1 * num2
        elif operation == "divide":
            if num2 == 0:
                messagebox.showerror("Error", "Division by zero is not allowed!")
                return
            result = num1 / num2
        
        # Display the result
        label_result.config(text=f"Result: {result}")
    except ValueError:
        messagebox.showerror("Error", "Please enter valid numbers!")

# Create the main application window
window = tk.Tk()
window.title("Simple Calculator")
window.geometry("400x300")
window.resizable(False, False)

# Add input fields for two numbers
tk.Label(window, text="Enter first number:").grid(row=0, column=0, padx=10, pady=10, sticky=tk.W)
entry_num1 = tk.Entry(window, width=20)
entry_num1.grid(row=0, column=1, padx=10, pady=10)

tk.Label(window, text="Enter second number:").grid(row=1, column=0, padx=10, pady=10, sticky=tk.W)
entry_num2 = tk.Entry(window, width=20)
entry_num2.grid(row=1, column=1, padx=10, pady=10)

# Add buttons for operations
tk.Button(window, text="Add", command=lambda: calculate("add")).grid(row=2, column=0, pady=10)
tk.Button(window, text="Subtract", command=lambda: calculate("subtract")).grid(row=2, column=1, pady=10)
tk.Button(window, text="Multiply", command=lambda: calculate("multiply")).grid(row=3, column=0, pady=10)
tk.Button(window, text="Divide", command=lambda: calculate("divide")).grid(row=3, column=1, pady=10)

# Add a label to display the result
label_result = tk.Label(window, text="Result: ", font=("Arial", 14))
label_result.grid(row=4, column=0, columnspan=2, pady=20)

# Run the Tkinter event loop
window.mainloop()
