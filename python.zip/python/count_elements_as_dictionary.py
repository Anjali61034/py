# Predefined list of numbers
numbers = [1, 2, 2, 3, 4, 4, 4, 5, 6, 6, 6, 6]

# Create a dictionary to store element counts
count_dict = {}

for num in numbers:
    count_dict[num] = count_dict.get(num, 0) + 1

# Display the resulting dictionary
print(f"List of numbers: {numbers}")
print(f"Element count dictionary: {count_dict}")
