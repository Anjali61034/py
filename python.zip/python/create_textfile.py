# List of Indian cities
cities = ["Mumbai", "Delhi", "Bangalore", "Hyderabad", "Ahmedabad", 
          "Chennai", "Kolkata", "Surat", "Pune", "Jaipur"]

# Create and write to the file
with open("indian_cities.txt", "w") as file:
    for city in cities:
        file.write(city + "\n")

print("File 'indian_cities.txt' has been created with the names of ten Indian cities.")
