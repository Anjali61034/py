# Define two sets
set1 = {1, 2, 3, 4, 5}
set2 = {4, 5, 6, 7, 8}

# Compute union, intersection, and difference
union = set1.union(set2)
intersection = set1.intersection(set2)
difference = set1.difference(set2)

# Display results
print(f"Set 1: {set1}")
print(f"Set 2: {set2}")
print(f"Union: {union}")
print(f"Intersection: {intersection}")
print(f"Difference (Set1 - Set2): {difference}")
