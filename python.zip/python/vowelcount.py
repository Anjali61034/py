# Create and write to the file
with open("vowel.txt", "w") as txt_file:
    txt_file.write("This is a simple example text to count vowels.")

# Open the file again in read mode
with open("vowel.txt", "r") as txt_file:
    # Initialize a counter for vowels
    vowel_count = 0
    # List of vowels (both uppercase and lowercase)
    vowels_list = "AEIOUaeiou"
    
    # Read the file content and count vowels (case-insensitive)
    for char in txt_file.read():
        if char in vowels_list:
            vowel_count += 1

# Print the result
print("Number of vowels in 'vowel.txt' =", vowel_count)
