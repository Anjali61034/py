# List of lines about the college
college_info = [
    "I study at XYZ College, which is located in the heart of the city.\n",
    "The college offers a wide variety of courses in various disciplines.\n",
    "It has a state-of-the-art library and well-equipped laboratories.\n",
    "The faculty members are highly qualified and supportive.\n",
    "The campus also has sports facilities, a cafeteria, and cultural events throughout the year.\n"
]

# Create and write lines to the file using writelines()
with open("college_info.txt", "w") as file:
    file.writelines(college_info)

print("File 'college_info.txt' has been created with details about the college.")
