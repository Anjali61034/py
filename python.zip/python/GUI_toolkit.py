import tkinter as tk
from tkinter import ttk

# Create the main window
root = tk.Tk()
root.title("Tkinter Widgets Example")

# Create a Label widget
label = tk.Label(root, text="This is a Label", font=("Arial", 14))
label.pack(pady=10)

# Create a Button widget
button = tk.Button(root, text="Click Me", font=("Arial", 12), command=lambda: label.config(text="Button Clicked"))
button.pack(pady=10)

# Create an Entry widget
entry = tk.Entry(root, font=("Arial", 12))
entry.pack(pady=10)

# Create a Checkbutton widget
check_button = tk.Checkbutton(root, text="Accept Terms and Conditions")
check_button.pack(pady=10)

# Create Radiobutton widgets
radio_var = tk.StringVar()
radiobutton1 = tk.Radiobutton(root, text="Option 1", variable=radio_var, value="Option 1")
radiobutton2 = tk.Radiobutton(root, text="Option 2", variable=radio_var, value="Option 2")
radiobutton1.pack(pady=5)
radiobutton2.pack(pady=5)

# Create a Listbox widget with a Scrollbar
listbox_frame = tk.Frame(root)
listbox_frame.pack(pady=10)

scrollbar = tk.Scrollbar(listbox_frame, orient="vertical")
listbox = tk.Listbox(listbox_frame, height=5, selectmode=tk.SINGLE, yscrollcommand=scrollbar.set)
scrollbar.config(command=listbox.yview)

# Insert items into the Listbox
for i in range(1, 11):
    listbox.insert(tk.END, f"Item {i}")

listbox.pack(side="left")
scrollbar.pack(side="right", fill="y")

# Create a Menu widget
menu_bar = tk.Menu(root)
root.config(menu=menu_bar)

file_menu = tk.Menu(menu_bar, tearoff=0)
menu_bar.add_cascade(label="File", menu=file_menu)
file_menu.add_command(label="New")
file_menu.add_command(label="Open")
file_menu.add_separator()
file_menu.add_command(label="Exit", command=root.quit)

# Create a ComboBox widget
combo_label = tk.Label(root, text="Select an option:")
combo_label.pack(pady=5)

combo = ttk.Combobox(root, values=["Option 1", "Option 2", "Option 3", "Option 4"])
combo.pack(pady=10)

# Create a SpinBox widget
spin_label = tk.Label(root, text="Select a number:")
spin_label.pack(pady=5)

spinbox = tk.Spinbox(root, from_=1, to=10)
spinbox.pack(pady=10)

# Create a Text widget (TextBox)
text_label = tk.Label(root, text="Enter multiple lines of text:")
text_label.pack(pady=5)

text_box = tk.Text(root, height=5, width=30)
text_box.pack(pady=10)

# Start the main loop
root.mainloop()
