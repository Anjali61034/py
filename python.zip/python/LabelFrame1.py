import tkinter as tk
from tkinter import messagebox

# Function to create widgets with all options
def create_widget(parent, widget_type, **options):
    return widget_type(parent, **options)

# Function to create buttons with all options
def create_button(parent, text, fg):
    return create_widget(
        parent, tk.Button, text=text, fg=fg, bg='lightblue', bd=3, cursor='hand2', 
        highlightcolor='red', highlightthickness=2, highlightbackground='black', relief=tk.RAISED
    )

# Sign up function to handle the form submission
def sign_up():
    username = username_entry.get()
    password = password_entry.get()
    confirm_password = confirm_password_entry.get()
    
    if password == confirm_password:
        messagebox.showinfo("Success", "User created successfully")
    else:
        messagebox.showerror("Error", "Passwords do not match")

# Create the main window
window = create_widget(None, tk.Tk)
window.title("Sign Up Page")

# Create the form frame
form_frame = create_widget(
    window, tk.Frame, bg='lightblue', bd=3, cursor='hand2', 
    highlightcolor='red', highlightthickness=2, highlightbackground='black', relief=tk.RAISED, width=300
)
form_frame.pack(padx=20, pady=20)

# Create the username label and entry
username_label = create_widget(form_frame, tk.Label, text='Username:', bg='lightblue')
username_label.pack(pady=5)

username_entry = create_widget(form_frame, tk.Entry)
username_entry.pack(pady=5)

# Create the password label and entry
password_label = create_widget(form_frame, tk.Label, text='Password:', bg='lightblue')
password_label.pack(pady=5)

password_entry = create_widget(form_frame, tk.Entry, show='*')
password_entry.pack(pady=5)

# Create the confirm password label and entry
confirm_password_label = create_widget(form_frame, tk.Label, text='Confirm Password:', bg='lightblue')
confirm_password_label.pack(pady=5)

confirm_password_entry = create_widget(form_frame, tk.Entry, show='*')
confirm_password_entry.pack(pady=5)

# Create a frame for the buttons
button_frame = create_widget(
    window, tk.Frame, bg='lightblue', bd=3, cursor='hand2', 
    highlightcolor='red', highlightthickness=2, highlightbackground='black', relief=tk.RAISED, width=200
)
button_frame.pack(pady=10)

# Create the sign-up button
sign_up_button = create_button(button_frame, text='Sign Up', fg='blue')
sign_up_button.config(command=sign_up)
sign_up_button.pack(side=tk.LEFT, padx=5)

# Start the main loop
window.mainloop()
