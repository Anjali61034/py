import tkinter as tk
from tkinter import ttk
from datetime import datetime

# Function to calculate age
def calculate_age():
    dob = dob_entry.get()
    try:
        # Convert the entered date to a datetime object
        dob_date = datetime.strptime(dob, "%Y-%m-%d")
        today = datetime.today()
        
        # Calculate age
        age = today.year - dob_date.year
        if today.month < dob_date.month or (today.month == dob_date.month and today.day < dob_date.day):
            age -= 1
        
        # Display the result
        result_label.config(text=f"Your age is: {age} years")
    except ValueError:
        result_label.config(text="Please enter a valid date in YYYY-MM-DD format.")

# Set up the main window
root = tk.Tk()
root.title("Age Calculator")

# Title label
title_label = ttk.Label(root, text="Age Calculator", font=("Helvetica", 16))
title_label.grid(row=0, column=0, padx=10, pady=10)

# Label and entry for DOB
dob_label = ttk.Label(root, text="Enter your Date of Birth (YYYY-MM-DD):")
dob_label.grid(row=1, column=0, padx=10, pady=5)
dob_entry = ttk.Entry(root)
dob_entry.grid(row=1, column=1, padx=10, pady=5)

# Calculate button
calculate_button = ttk.Button(root, text="Calculate Age", command=calculate_age)
calculate_button.grid(row=2, column=0, columnspan=2, padx=10, pady=10)

# Label to display the result
result_label = ttk.Label(root, text="", font=("Helvetica", 12))
result_label.grid(row=3, column=0, columnspan=2, padx=10, pady=10)

# Start the main loop
root.mainloop()
