import csv

def create_student_csv(file_name):
    # Define the header for the CSV file
    headers = ['Roll_No', 'Enrollment_No', 'Name', 'Course', 'Semester']
    
    # Sample student data
    student_data = [
        [1, '2022001', 'Alice', 'B.Sc. Computer Science', 3],
        [2, '2022002', 'Bob', 'B.Sc. Computer Science', 3],
        [3, '2022003', 'Charlie', 'B.Sc. Mathematics', 2]
    ]
    
    # Create and write to the CSV file
    with open(file_name, mode='w', newline='') as file:
        writer = csv.writer(file)
        
        # Write the header
        writer.writerow(headers)
        
        # Write the student data
        writer.writerows(student_data)
    
    print(f"CSV file '{file_name}' created successfully.")

# Usage
create_student_csv("students.csv")


"""filterout file"""


import csv

def filter_second_semester_students(file_name):
    try:
        # Open the CSV file for reading
        with open(file_name, mode='r') as file:
            reader = csv.DictReader(file)
            
            # Filter students in the II semester
            second_semester_students = [
                row for row in reader if row['Semester'] == '2'
            ]
            
            # Display the filtered records
            print("Students in II Semester:")
            for student in second_semester_students:
                print(student)
                
    except FileNotFoundError:
        print(f"File '{file_name}' not found. Please make sure the file exists.")
    except Exception as e:
        print("An error occurred:", e)

# Usage
filter_second_semester_students("students.csv")
