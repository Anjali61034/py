def swap_characters(s):
    # Check if the string is too short for swapping
    if len(s) < 4:
        return "String is too short to swap characters."
    
    # Swap first two and last two characters
    new_string = s[-2:] + s[2:-2] + s[:2]
    return new_string

# Example usage
input_string = input("Enter a string: ")
result = swap_characters(input_string)
print("Result:", result)
