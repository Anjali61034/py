import tkinter as tk
from tkinter import ttk
import csv

# Function to save student details to a CSV file
def save_details():
    roll_no = roll_no_entry.get()
    enrollment_no = enrollment_no_entry.get()
    name = name_entry.get()
    course = course_entry.get()
    semester = semester_entry.get()

    # Write the details to a CSV file
    with open('student_details.csv', mode='a', newline='') as file:
        writer = csv.writer(file)
        
        # If the file is empty, write the header row
        if file.tell() == 0:
            writer.writerow(["Roll_No", "Enrollment_No", "Name", "Course", "Semester"])
        
        # Write the entered student details
        writer.writerow([roll_no, enrollment_no, name, course, semester])

    # Display success message
    status_label.config(text="Student details saved successfully!", fg="green")

# Initialize Tkinter window
root = tk.Tk()
root.title("Student Details Form")

# Title label
title_label = ttk.Label(root, text="Enter Student Details", font=("Helvetica", 16))
title_label.grid(row=0, column=0, columnspan=2, pady=10)

# Roll Number
roll_no_label = ttk.Label(root, text="Roll No:")
roll_no_label.grid(row=1, column=0, padx=10, pady=5, sticky=tk.W)
roll_no_entry = ttk.Entry(root)
roll_no_entry.grid(row=1, column=1, padx=10, pady=5)

# Enrollment Number
enrollment_no_label = ttk.Label(root, text="Enrollment No:")
enrollment_no_label.grid(row=2, column=0, padx=10, pady=5, sticky=tk.W)
enrollment_no_entry = ttk.Entry(root)
enrollment_no_entry.grid(row=2, column=1, padx=10, pady=5)

# Name
name_label = ttk.Label(root, text="Name:")
name_label.grid(row=3, column=0, padx=10, pady=5, sticky=tk.W)
name_entry = ttk.Entry(root)
name_entry.grid(row=3, column=1, padx=10, pady=5)

# Course
course_label = ttk.Label(root, text="Course:")
course_label.grid(row=4, column=0, padx=10, pady=5, sticky=tk.W)
course_entry = ttk.Entry(root)
course_entry.grid(row=4, column=1, padx=10, pady=5)

# Semester
semester_label = ttk.Label(root, text="Semester:")
semester_label.grid(row=5, column=0, padx=10, pady=5, sticky=tk.W)
semester_entry = ttk.Entry(root)
semester_entry.grid(row=5, column=1, padx=10, pady=5)

# Save button
save_button = ttk.Button(root, text="Save", command=save_details)
save_button.grid(row=6, column=0, columnspan=2, pady=10)

# Status label to show success or error message
status_label = ttk.Label(root, text="", font=("Helvetica", 10))
status_label.grid(row=7, column=0, columnspan=2, pady=5)

# Start the main loop
root.mainloop()
