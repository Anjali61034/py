# Predefined list of numbers
numbers = [10, 20, 30, 40, 50]

# Calculate sum and average
total = sum(numbers)
average = total / len(numbers)

# Print results
print(f"List of numbers: {numbers}")
print(f"Sum of numbers: {total}")
print(f"Average of numbers: {average}")
