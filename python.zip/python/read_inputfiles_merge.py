# Define input file names
input_files = ['employee_file1.txt', 'employee_file2.txt', 'employee_file3.txt']
output_file = 'merged_employees.txt'

# Open the output file in write mode
with open(output_file, 'w') as outfile:
    # Loop through each input file
    for file_name in input_files:
        try:
            # Open each input file in read mode
            with open(file_name, 'r') as infile:
                # Read the content and write it to the output file
                content = infile.read()
                outfile.write(content + '\n')  # Add a newline after each file's content
        except FileNotFoundError:
            print(f"Error: {file_name} not found.")
            
print(f"Employee names from all files have been merged into '{output_file}'.")
