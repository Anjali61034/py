import tkinter as tk
from tkinter import messagebox

def submit_details():
    # Retrieve the data entered by the user
    name = entry_name.get()
    email = entry_email.get()
    contact = entry_contact.get()
    event = entry_event.get()

    # Validate input fields
    if not name or not email or not contact or not event:
        messagebox.showerror("Error", "All fields are required!")
        return

    # Display confirmation
    messagebox.showinfo("Success", f"Registration Successful!\n\nDetails:\nName: {name}\nEmail: {email}\nContact: {contact}\nEvent: {event}")

    # Clear the input fields
    entry_name.delete(0, tk.END)
    entry_email.delete(0, tk.END)
    entry_contact.delete(0, tk.END)
    entry_event.delete(0, tk.END)

# Create the main application window
window = tk.Tk()
window.title("Event Registration Form")
window.geometry("400x300")
window.resizable(False, False)

# Add labels and entry fields
tk.Label(window, text="Name:").grid(row=0, column=0, padx=10, pady=10, sticky=tk.W)
entry_name = tk.Entry(window, width=30)
entry_name.grid(row=0, column=1, padx=10, pady=10)

tk.Label(window, text="Email:").grid(row=1, column=0, padx=10, pady=10, sticky=tk.W)
entry_email = tk.Entry(window, width=30)
entry_email.grid(row=1, column=1, padx=10, pady=10)

tk.Label(window, text="Contact No:").grid(row=2, column=0, padx=10, pady=10, sticky=tk.W)
entry_contact = tk.Entry(window, width=30)
entry_contact.grid(row=2, column=1, padx=10, pady=10)

tk.Label(window, text="Event Name:").grid(row=3, column=0, padx=10, pady=10, sticky=tk.W)
entry_event = tk.Entry(window, width=30)
entry_event.grid(row=3, column=1, padx=10, pady=10)

# Add the Submit button
submit_button = tk.Button(window, text="Submit", command=submit_details)
submit_button.grid(row=4, column=0, columnspan=2, pady=20)

# Run the Tkinter event loop
window.mainloop()
